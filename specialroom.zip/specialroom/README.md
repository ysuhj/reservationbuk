# 북가좌초 특별실 현황·예약

학교 특별실 사용 현황을 일간·주간·월간으로 보고, 빈 교시를 예약하는 웹앱입니다.
기존 구글 시트(특별실 사용 및 시설보수 요청)를 그대로 데이터로 씁니다.

```
docs/          웹앱 화면 (GitHub Pages로 공개)
apps-script/   시트를 읽고 쓰는 API (Google Apps Script에 붙여 넣기)
desktop/       Windows PC 앱 (Electron)
.github/       PC 앱 자동 빌드 설정
```

## 1. API 준비 (Apps Script)

1. 구글 시트에서 **확장 프로그램 → Apps Script**를 엽니다.
2. `Code.gs` 내용을 `apps-script/Code.gs`로 바꿉니다. 예전 `Index` HTML 파일은 지워도 됩니다.
3. **프로젝트 설정(톱니바퀴) → 스크립트 속성 → 속성 추가**
   - 속성: `SCHOOL_PASSWORD` / 값: 선생님들께 알려 줄 학교 비밀번호
4. 편집기에서 `getInit` 함수를 한 번 실행해 권한을 승인합니다.
5. **배포 → 새 배포 → 웹 앱**
   - 실행 사용자: **나**
   - 액세스 권한: **모든 사용자** (GitHub 화면에서 접속하려면 이 설정이어야 합니다. 대신 학교 비밀번호로 막습니다.)
6. 나온 주소(`…/exec`)를 복사합니다.

> 코드를 고친 뒤에는 **배포 관리 → 연필 → 버전: 새 버전**으로 다시 배포해야 반영됩니다. 주소는 그대로 유지됩니다.

## 2. 웹앱 공개 (GitHub Pages)

1. 이 폴더 전체를 GitHub 저장소(예: `specialroom`)에 올립니다.
2. `docs/config.js`에 1-6의 주소와 PC 앱 다운로드 주소를 넣습니다.
3. 저장소 **Settings → Pages → Branch: main / 폴더: /docs → Save**
4. 1~2분 뒤 `https://사용자명.github.io/specialroom/` 에서 열립니다.

선생님들은 이 주소에서 학교 비밀번호를 한 번 입력하면 됩니다. 크롬·엣지·웨일에서는 주소창 오른쪽이나 화면 위 **앱 설치** 버튼으로 바탕화면 앱처럼 설치할 수 있습니다(관리자 권한 필요 없음).

## 3. PC 앱 (Windows 설치 파일)

1. `desktop/main.js`의 `APP_URL`을 GitHub Pages 주소로 바꿉니다.
2. 저장소 **Actions** 탭에서 워크플로를 허용합니다.
3. 태그를 올리면 자동으로 설치 파일이 만들어져 **Releases**에 올라갑니다.
   ```
   git tag v1.0.0
   git push origin v1.0.0
   ```
   (GitHub 웹에서 **Releases → Draft a new release → 태그 v1.0.0 만들기 → Publish**로 해도 됩니다.)
4. 선생님들은 웹앱의 **PC 앱 받기** 버튼이나 Releases 페이지에서 `specialroom-setup-1.0.0.exe`를 내려받아 설치합니다.

PC 앱은 GitHub Pages 화면을 띄우는 방식이라, 웹앱만 고치면 PC 앱에도 바로 반영됩니다. 앱을 다시 만들 필요는 `main.js`나 아이콘을 바꿀 때뿐입니다.

> 코드 서명을 하지 않은 설치 파일이라 처음 실행할 때 Windows가 “PC 보호” 창을 띄울 수 있습니다. **추가 정보 → 실행**을 누르면 설치됩니다.

## 시트 쪽에서 관리하는 것

- **시정표** 탭: 교시별 시간 (처음 실행 때 자동 생성)
- **공지사항** 탭: 웹앱 아래 공지에 그대로 표시
- **소통보드** 탭: 웹앱 메모 (상태 칸에 `삭제`라고 쓰면 숨겨짐)
- **예약기록** 탭(숨김): 모든 예약·수정·비우기 이력
- 학교 비밀번호 변경: Apps Script 스크립트 속성의 `SCHOOL_PASSWORD` 값만 바꾸면 됩니다.
